#!python


if __name__ == '__main__':
    foo = 1
    print foo

