#!python

print "hi"
print "bye"

