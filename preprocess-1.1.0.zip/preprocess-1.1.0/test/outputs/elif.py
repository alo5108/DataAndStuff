#!python

if __name__ == '__main__':
    print "c"
    print "bye"

