#!python


print "FOO_NONE"
print "FOO_INT"
print "FOO_FLOAT"
print "FOO_STRING1"
print "FOO_STRING2"
print "FOO_LIST"
print "FOO_TUPLE"
print "FOO_DICT"
