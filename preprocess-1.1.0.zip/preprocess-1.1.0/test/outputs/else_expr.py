#!python

if __name__ == '__main__':
    print "hi"
# #else ZERO
    print "hello"
    print "bye"

