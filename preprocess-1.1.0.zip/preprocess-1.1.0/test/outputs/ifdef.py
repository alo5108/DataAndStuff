#!python

if __name__ == '__main__':
    print "ONE defined"
    print "ZERO defined"
    print "FOO not defined"
    print "bye"

