#!python

if __name__ == '__main__':
    print "ASDF not defined"
    print "bye"

