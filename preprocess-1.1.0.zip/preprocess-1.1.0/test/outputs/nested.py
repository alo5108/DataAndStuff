#!python

if __name__ == '__main__':
    print "one"
    print "un"
    print "still, just one"
    print "bye"

