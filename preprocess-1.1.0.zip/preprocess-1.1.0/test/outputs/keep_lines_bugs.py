# Test a bug where --keep-lines wasn't obeyed for directives inside
# skipped #if-blocks.

print "this is line 4"







print "this is line 12"


print "this is line 15"

