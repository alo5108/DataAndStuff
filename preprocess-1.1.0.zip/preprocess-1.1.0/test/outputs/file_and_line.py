
print "__FILE__ is defined"

print "__FILE__.endswith('file_and_line.py')"

print "__LINE__ is defined"

print "__LINE__ is 14"

print "__LINE__ is 18"
