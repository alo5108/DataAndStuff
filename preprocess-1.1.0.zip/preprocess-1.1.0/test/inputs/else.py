#!python

# #define ZERO 0
if __name__ == '__main__':
# #if ZERO
    print "zero"
# #else
    print "not zero"
# #endif
    print "bye"

