#!python

# #define ONE 1
# #define ZERO 0
# #define UN 1
if __name__ == '__main__':
# #if ONE
    print "hi"
# #endif
    print "bye"

