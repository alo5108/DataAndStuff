# #if 1
print "1"
# #else
print "not 1"
# #elif 0
print "0"
# #endif

