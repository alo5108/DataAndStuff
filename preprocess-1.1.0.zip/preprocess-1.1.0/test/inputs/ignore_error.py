#!python

print "hi"
# #if 0

# The following should not cause an error, but did up until
# preprocess v0.6.1.
# #error womba womba womba

# #endif
print "bye"

