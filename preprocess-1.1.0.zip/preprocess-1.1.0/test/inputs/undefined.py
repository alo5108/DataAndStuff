#!python

if __name__ == '__main__':
# #if FOO
    print "foo is not defined"
# #endif
    print "bye"

