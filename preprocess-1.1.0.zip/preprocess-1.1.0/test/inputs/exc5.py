# #if defined(FOO)
print "foo"
# #endif

