#!python

# #define FOO_NONE
# #define FOO_INT 42
# #define FOO_FLOAT 3.14
# #define FOO_STRING1 foo
# #define FOO_STRING2 "foo"
# #define FOO_LIST [1, 'a', 2.5]
# #define FOO_TUPLE (1, 'a', 2.5)
# #define FOO_DICT {'a':1, 'b':2}

# #if FOO_NONE is None
print "FOO_NONE"
# #endif
# #if FOO_INT == 42
print "FOO_INT"
# #endif
# #if FOO_FLOAT == 3.14
print "FOO_FLOAT"
# #endif
# #if FOO_STRING1 == "foo"
print "FOO_STRING1"
# #endif
# #if FOO_STRING2 == "foo"
print "FOO_STRING2"
# #endif
# #if FOO_LIST == [1, 'a', 2.5]
print "FOO_LIST"
# #endif
# #if FOO_TUPLE == (1, 'a', 2.5)
print "FOO_TUPLE"
# #endif
# #if FOO_DICT == {'a':1, 'b':2}
print "FOO_DICT"
# #endif
