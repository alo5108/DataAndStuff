#!python

# #define ONE 1
# #define ZERO 0
# #define UN 1
if __name__ == '__main__':
# #ifndef ONE
    print "ONE not defined"
# #else
    print "ONE defined"
# #endif
# #ifndef ZERO
    print "ZERO not defined"
# #else
    print "ZERO defined"
# #endif
# #ifndef FOO
    print "FOO not defined"
# #else
    print "FOO defined"
# #endif
    print "bye"

