#!python

"""This is a Python file with NO preprocessor stmts in it."""

if __name__ == '__main__':
    print "hi"

