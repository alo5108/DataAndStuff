#!python

if __name__ == '__main__':
# #if defined('ASDF')
    print "ASDF defined"
# #else
    print "ASDF not defined"
# #endif
    print "bye"

