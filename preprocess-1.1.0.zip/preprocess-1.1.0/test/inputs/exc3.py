# #if 0
print "0"
# #endif
# #endif
