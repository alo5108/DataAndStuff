#!python

# #define ONE 1
# #define ZERO 0
# #define UN 1
if __name__ == '__main__':
# #if ONE
    print "one"
# #if UN
    print "un"
# #endif
    print "still, just one"
# #if ZERO
    print "zero"
# #endif
# #endif
    print "bye"

