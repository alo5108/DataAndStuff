#!python

# #define ONE 1
# #define ZERO 0
# #define UN 1
if __name__ == '__main__':
# #ifdef ONE
    print "ONE defined"
# #else
    print "ONE not defined"
# #endif
# #ifdef ZERO
    print "ZERO defined"
# #else
    print "ZERO not defined"
# #endif
# #ifdef FOO
    print "FOO defined"
# #else
    print "FOO not defined"
# #endif
    print "bye"

